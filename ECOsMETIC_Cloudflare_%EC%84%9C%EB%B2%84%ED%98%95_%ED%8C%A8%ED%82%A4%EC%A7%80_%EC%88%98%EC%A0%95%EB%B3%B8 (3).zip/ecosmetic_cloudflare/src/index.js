const COOKIE = 'eco_admin';
const SESSION_SECONDS = 60 * 60 * 2;
const DEFAULT_CONTENT = {
  products: [
    {id:1,name:'리필 수분 크림',category:'크림',price:'18,000원',tag:'리필 가능',visual:'jar',image:''},
    {id:2,name:'식물 유래 토너',category:'토너',price:'16,000원',tag:'식물 유래 성분',visual:'bottle',image:''},
    {id:3,name:'고체 클렌징 바',category:'클렌징폼',price:'11,000원',tag:'플라스틱 절감',visual:'bar',image:''},
    {id:4,name:'내추럴 립밤',category:'립밤',price:'9,000원',tag:'재활용 소재',visual:'bottle',image:''}
  ],
  ranking: [
    {tag:'REFILL',name:'리필 수분 크림',desc:'리필형 용기'},
    {tag:'LESS PLASTIC',name:'고체 클렌징 바',desc:'플라스틱 포장 절감'},
    {tag:'PLANT-BASED',name:'식물 유래 토너',desc:'식물 유래 성분 콘셉트'}
  ]
};
const json = (data, status=200, headers={}) => new Response(JSON.stringify(data), {status, headers:{'content-type':'application/json; charset=utf-8', 'cache-control':'no-store', ...headers}});
function b64(bytes) { let s=''; for (const b of new Uint8Array(bytes)) s += String.fromCharCode(b); return btoa(s).replace(/\+/g,'-').replace(/\//g,'_').replace(/=+$/,''); }
function unb64(s) { s=s.replace(/-/g,'+').replace(/_/g,'/'); while(s.length%4)s+='='; return Uint8Array.from(atob(s),c=>c.charCodeAt(0)); }
async function sign(value, secret) { const key=await crypto.subtle.importKey('raw',new TextEncoder().encode(secret),{name:'HMAC',hash:'SHA-256'},false,['sign']); return b64(await crypto.subtle.sign('HMAC',key,new TextEncoder().encode(value))); }
async function makeToken(secret) { const payload=b64(new TextEncoder().encode(JSON.stringify({exp:Math.floor(Date.now()/1000)+SESSION_SECONDS,nonce:crypto.randomUUID()}))); return payload+'.'+await sign(payload,secret); }
async function validSession(request, secret) { const cookie=request.headers.get('Cookie')||''; const match=cookie.split(';').map(x=>x.trim()).find(x=>x.startsWith(COOKIE+'=')); if(!match)return false; const token=decodeURIComponent(match.slice(COOKIE.length+1)); const [payload,sig]=token.split('.'); if(!payload||!sig)return false; const expected=await sign(payload,secret); if(sig.length!==expected.length)return false; let diff=0; for(let i=0;i<sig.length;i++)diff|=sig.charCodeAt(i)^expected.charCodeAt(i); if(diff)return false; try{return JSON.parse(new TextDecoder().decode(unb64(payload))).exp>Math.floor(Date.now()/1000);}catch{return false;} }
const cookieHeader = value => `${COOKIE}=${encodeURIComponent(value)}; HttpOnly; Secure; SameSite=Strict; Path=/; Max-Age=${SESSION_SECONDS}`;
const clearCookie = `${COOKIE}=; HttpOnly; Secure; SameSite=Strict; Path=/; Max-Age=0`;
async function getContent(db) { const row=await db.prepare('SELECT payload FROM site_content WHERE id=1').first(); if(!row)return DEFAULT_CONTENT; try{return JSON.parse(row.payload);}catch{return DEFAULT_CONTENT;} }
function validateContent(body) {
 if(!body||!Array.isArray(body.products)||!Array.isArray(body.ranking)||body.products.length>200||body.ranking.length>10) return false;
 const productKeys=['id','name','category','price','tag','image','visual'];
 for(const p of body.products){if(!p||!Number.isSafeInteger(Number(p.id))||!String(p.name||'').trim()||!String(p.category||'').trim())return false; for(const k of productKeys)if(k in p && String(p[k]??'').length>2000)return false;}
 for(const r of body.ranking){if(!r||!String(r.name||'').trim()||String(r.name).length>100||String(r.tag||'').length>40||String(r.desc||'').length>200)return false;}
 return true;
}
export default {
 async fetch(request, env) {
  const url=new URL(request.url); const path=url.pathname;
  if(path==='/health') return json({ok:true,service:'ECOsMETIC API'});
  if(path.startsWith('/api/')) {
   if(!env.DB) return json({error:'D1 database binding DB is missing'},500);
   if(path==='/api/content' && request.method==='GET') return json(await getContent(env.DB));
   if(path==='/api/login' && request.method==='POST') {
    if(!env.ADMIN_PASSWORD||!env.SESSION_SECRET) return json({error:'Server secrets are not configured'},500);
    const ip=request.headers.get('CF-Connecting-IP')||'unknown';
    const ipHash=await crypto.subtle.digest('SHA-256',new TextEncoder().encode(ip)); const key=b64(ipHash);
    const now=Math.floor(Date.now()/1000);
    await env.DB.prepare('DELETE FROM login_limits WHERE window_start < ?').bind(now-900).run();
    let row=await env.DB.prepare('SELECT attempts, window_start FROM login_limits WHERE ip_hash=?').bind(key).first();
    if(row && row.window_start>now-900 && row.attempts>=8) return json({error:'Too many attempts'},429);
    let body; try{body=await request.json();}catch{return json({error:'Invalid JSON'},400);}
    if(typeof body.password!=='string' || body.password!==env.ADMIN_PASSWORD) {
      if(row && row.window_start>now-900) await env.DB.prepare('UPDATE login_limits SET attempts=attempts+1 WHERE ip_hash=?').bind(key).run();
      else await env.DB.prepare('INSERT OR REPLACE INTO login_limits(ip_hash,attempts,window_start) VALUES(?,?,?)').bind(key,1,now).run();
      return json({error:'Unauthorized'},401);
    }
    await env.DB.prepare('DELETE FROM login_limits WHERE ip_hash=?').bind(key).run();
    const token=await makeToken(env.SESSION_SECRET);
    return json({ok:true},200,{'set-cookie':cookieHeader(token)});
   }
   if(path==='/api/logout' && request.method==='POST') return json({ok:true},200,{'set-cookie':clearCookie});
   if(path==='/api/content' && request.method==='PUT') {
    if(!await validSession(request,env.SESSION_SECRET||'')) return json({error:'Unauthorized'},401);
    let body; try{body=await request.json();}catch{return json({error:'Invalid JSON'},400);}
    if(!validateContent(body)) return json({error:'Invalid content'},400);
    await env.DB.prepare('INSERT INTO site_content(id,payload,updated_at) VALUES(1,?,?) ON CONFLICT(id) DO UPDATE SET payload=excluded.payload, updated_at=excluded.updated_at').bind(JSON.stringify(body),new Date().toISOString()).run();
    return json({ok:true});
   }
   return json({error:'Not found'},404);
  }
  if(env.ASSETS) return env.ASSETS.fetch(request);
  return new Response('Static assets binding ASSETS is missing',{status:500});
 }
};
