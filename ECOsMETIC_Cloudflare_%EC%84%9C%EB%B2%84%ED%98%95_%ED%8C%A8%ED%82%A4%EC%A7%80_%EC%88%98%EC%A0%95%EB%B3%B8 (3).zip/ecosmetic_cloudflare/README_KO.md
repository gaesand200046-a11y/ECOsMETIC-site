# ECOsMETIC 서버형 사이트 (Cloudflare Workers + D1)

이 프로젝트는 기존 ECOsMETIC 미리보기 디자인을 유지하고, 관리자 인증과 콘텐츠 저장을 Cloudflare Worker/D1로 처리합니다.

## 포함된 기능
- 방문자 공개 열람
- 관리자 서버 로그인 및 2시간 HttpOnly 세션 쿠키
- 관리자 로그인 시도 제한
- 상품 추가/수정/삭제 및 The Green Edit 편집 내용의 D1 저장
- `/health` 상태 확인

## 배포 전 필수 설정
1. Cloudflare 대시보드에서 D1 데이터베이스를 `cosmetic-db` 이름으로 만듭니다.
2. 생성 결과의 database ID를 `wrangler.toml`의 `REPLACE_WITH_DATABASE_ID`에 넣습니다.
3. 터미널에서 `npm install` 실행 후 아래 명령을 실행합니다.

```bash
npx wrangler d1 migrations apply cosmetic-db --remote
npx wrangler secret put ADMIN_PASSWORD
npx wrangler secret put SESSION_SECRET
npx wrangler deploy
```

`ADMIN_PASSWORD`에는 관리자 비밀번호를 입력합니다. `SESSION_SECRET`에는 충분히 긴 임의 문자열을 입력합니다. 두 값 모두 채팅에 보내지 말고 Cloudflare 터미널 입력란에 직접 입력하세요.

배포 후 `https://프로젝트이름.계정이름.workers.dev/health`에서 `{"ok":true,...}`가 나오면 Worker가 응답하는 것입니다. 실제 사이트 주소는 배포 출력에 표시되는 workers.dev 주소입니다.

## 주의
- `wrangler.toml`의 database ID 교체 및 Cloudflare 계정 배포가 끝나기 전에는 공개 서버 사이트가 아닙니다.
- 기존 미리보기 HTML의 `/api/content`, `/api/login`, `/api/logout` 요청을 Worker가 처리하도록 구성했습니다.
- 기본 상품은 D1에 저장된 데이터가 없을 때만 표시됩니다. 첫 관리자 저장부터 D1에 보관됩니다.
